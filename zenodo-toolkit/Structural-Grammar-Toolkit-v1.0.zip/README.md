# Structural Grammar Toolkit v1.0
# 通用结构语法 · 工具包 v1.0

**Companion to / 配套文献**

Ning, Kaifeng. *A General Structural Grammar for the Governance of Complex Systems: A Methodological Framework.* Zenodo, 2026.
DOI: 10.5281/zenodo.xxxxxxx  ← 请替换为论文的概念 DOI

Ning, Kaifeng. *复杂系统治理的通用结构语法：方法论框架*. Zenodo, 2026.（中文版，同一 DOI）

---

## What this is / 这是什么

The paper argues *why* governance needs a structural grammar. This toolkit shows *how* to run one.

四份文档，把论文的方法论变成可以直接动手的东西：一张能填的表、一份能查的提示、三份填好的样例、一页导航。

这套工具包不增加任何理论主张。它的全部内容都来自论文本身与随后的标本实践。

Nothing in this toolkit adds a theoretical claim. Everything in it comes from the paper and from the specimen work that followed.

---

## Contents / 包含什么

| File | Form | Use when |
|---|---|---|
| `01_Overview.pdf` / `.docx` | Navigation / 导航 | First contact; or when handing the toolkit to someone else |
| `02_Worksheet_v2.pdf` / `.docx` | Fillable form / 可填表单 | Actually doing a diagnosis. One per system |
| `03_PromptCard.pdf` / `.docx` | Quick reference / 速查 | Before filling each box: how to ask, where people go wrong |
| `04_WorkedExamples.pdf` / `.docx` | Three completed worksheets / 三份填好的表 | Learning what a good answer looks like |

Every document is bilingual: Chinese section first, English section following (the Worksheet has one full page per language; the others are section-by-section).

每份文档都是中英双语。工作表是中英各一整页，其余为分节对照。

**PDF for reading and citing; DOCX for editing.** The Worksheet is meant to be printed or copied — that is its purpose.

---

## How to use it / 怎么用

**Path A — Reader / 读者**
Read the paper §1–§3 → look at the Worksheet to see the shape of an answer → run the Prompt Card questions on yourself → return to §4–§7.

**Path B — Practitioner / 实践者**
Worksheet "Pre-check 0" (three conditions must pass) → fill ①–⑤, checking each against the Prompt Card → ⑥ four questions → ⑦ self-check → ⑧ validation ladder.

**Path C — Reviewer / 评审者**
Skip ①②. Take the Prompt Card's "common errors" and check someone else's diagnosis against it, item by item.

---

## One divergence from the paper: four states vs five
## 与论文的一处差异：四态与五态

The paper (§3.1) presents a four-state grid. This toolkit uses five states, adding **Evasive lock-in（讳锁）**.

论文 §3.1 给的是四态网格。工具包用五态，新增「讳锁（Evasive lock-in）」。

| | Paper v1 | Toolkit v2.0 |
|---|---|---|
| States | four | **five** (+Evasive) |
| Constraint mutability | three classes | **four** (+Evasive) |
| Source | methodological derivation | a form that emerged in practice (Specimen No.03) |

**This is a granularity difference, not a version conflict.** The two-by-two grid is unchanged; one cell has been split into two.

**这不是版本冲突，是颗粒度差异。** 二值网格没有变，只是把其中一格拆成了两档。

Why split it: a constraint that is formally fully adjustable, but whose use would immediately expose the loss, so that no one moves first — classified as *adjustable*, it invites an attempt to change it directly; classified as *solidified*, it invites waiting for external force. Both prescriptions are wrong.

为什么要拆：约束"形式上完全可调、但动用即暴露损失、于是无人先动"，归入可调会误以为可以直接改，归入固化会误以为只能等外部力量——两条药方都开错。

Full note: see the last page of the Worksheet.

---

## What this toolkit does not provide
## 这套工具包不提供什么

- No quantitative thresholds / 不给数值阈值
- No direct answers / 不给直接答案
- No substitute for the bearer's judgement / 不替系统定义存续单位
- No normative verdicts / 不评对错
- No cross-scale uniform thresholds / 不承诺跨领域统一阈值

It judges structure, not right and wrong. Whether something *ought* to be done belongs to the normative layer, which is left as an interface.

它判结构，不判善恶。"该不该做"属于规范层，留作接口。

---

## Citation / 引用

If you cite the toolkit:

> Ning, Kaifeng. 2026. *Structural Grammar Toolkit v1.0: Diagnostic Worksheet, Prompt Card, and Worked Examples*. Zenodo. https://doi.org/10.5281/zenodo.xxxxxxx

**This toolkit will be updated as more specimens are completed. Please cite the concept DOI, not a version DOI**, so that the reference resolves to the current version.

**本工具包会随标本增加而更新。请引用概念 DOI，不要引用版本 DOI**，这样引用总指向当前版本。

For the methodology itself, cite the paper, not this toolkit.

方法论本身请引用论文，不要引用本工具包。

---

## License / 许可

CC BY 4.0. Use, adapt, translate, and redistribute freely, including commercially, with attribution.

可自由使用、改编、翻译、再分发（含商业用途），须署名。

---

## Contact

Ning Kaifeng（宁凯峰）· Independent Researcher
ORCID: 0009-0001-4414-6058
https://zhishuixue.com

Corrections and counterexamples are especially welcome. If you have found a system this grammar misjudges, that is more useful than a system it handles well.

**最欢迎的是反例。** 如果你找到一个这套语法会判错的系统，那比找到一个它判得好的系统有用得多。
